#!/bin/sh
LD_LIBRARY_PATH=./lib ./gravity-bin
